print("Hello World, Nachiket has begun learning Computer Science!")
x=2
y=4
if x+y == 6:
    print("Getting the hang of it slowly")
