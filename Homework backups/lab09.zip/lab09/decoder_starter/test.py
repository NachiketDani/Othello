test_list = []

string_test = "".join(test_list)
print(string_test)
