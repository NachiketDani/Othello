
class Player:
    """
    A class representing a dodgeball player
    """
    # Dodgeball player name, number and position they play in
    def __init__(self, player_name, player_number, player_position):
        self.player_name = player_name
        self.player_number = player_number
        self.player_position = player_position
