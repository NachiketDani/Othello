# Get input.
word1 = input("Enter word #1: ")
word2 = input("Enter word #2: ")

# Enter your code here to swap what’s 
# in the variables word1 and word2.
word3=word1
word1=word2
word2=word3
# Print results.
print () # prints blank line

print("Swapping results")
print("word #1:", word1)
print("word #2:", word2)